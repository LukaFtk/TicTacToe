namespace TicTacToe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            playeroneLabel.Visible = false;
            playeroneName.Visible = false;
            playertwoLabel.Visible = false;
            playertwoName.Visible = false;
            roundsLabel.Visible = false;
            roundsNumber.Visible = false;
            confirmButton.Visible = false;

          
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            playButton.Visible = false;
            label1.Visible = false;

            playeroneLabel.Visible = true;
            playeroneName.Visible = true;
            playertwoLabel.Visible = true;
            playertwoName.Visible = true;
            roundsLabel.Visible = true;
            roundsNumber.Visible = true;
            confirmButton.Visible = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public string PlayerOneName { get; private set; }
        public string PlayerTwoName { get; private set; }
        public int Rounds { get; private set; }
        private void confirmButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(playeroneName.Text) ||
               string.IsNullOrEmpty(playertwoName.Text) ||
               string.IsNullOrEmpty(roundsNumber.Text))
            {
                MessageBox.Show("sheavset yvela zoli!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int rounds;
            if (!int.TryParse(roundsNumber.Text, out rounds) || rounds <= 0)
            {
                MessageBox.Show("sheiyvanet cifri da amavdroulad 0-ze meti!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                roundsNumber.Focus();
                roundsNumber.SelectAll();
                return;
            }
            else
            {
                PlayerOneName = playeroneName.Text;
                PlayerTwoName = playertwoName.Text;
                Rounds = int.Parse(roundsNumber.Text);


                Form2 form2 = new Form2(PlayerOneName, PlayerTwoName, Rounds);
                form2.Show();
                this.Hide();
            }
        }
    }
}