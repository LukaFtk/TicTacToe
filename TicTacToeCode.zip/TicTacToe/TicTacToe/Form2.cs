﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading.Tasks;
namespace TicTacToe
{
    public partial class Form2 : Form
    {
        private string playerOneName;
        private string playerTwoName;
        private int rounds;
        public Form2(string playerOneName, string playerTwoName, int rounds)
        {
            InitializeComponent();
            this.playerOneName = playerOneName;
            this.playerTwoName = playerTwoName;
            this.rounds = rounds;

            if (playerOneName == playerTwoName)
            {
                playerOneName += "1";
                playerTwoName += "2";
            }

            player1Name.Text = playerOneName;
            player2Name.Text = playerTwoName;

            player1Rounds.ReadOnly = true;
            player2Rounds.ReadOnly = true;
            player1Rounds.Enabled = false;
            player2Rounds.Enabled = false;

            nextRoundButton.Visible = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private static int playerTurn = 1;
        private void buttonsLocker(bool status = true)
        {
            button11.Enabled = status;
            button12.Enabled = status;
            button13.Enabled = status;
            button21.Enabled = status;
            button22.Enabled = status;
            button23.Enabled = status;
            button31.Enabled = status;
            button32.Enabled = status;
            button33.Enabled = status;
        }
        private bool fullBoardChecker()
        {
            if ((button11.Text != "X") && (button11.Text != "O")) return false;
            if ((button12.Text != "X") && (button12.Text != "O")) return false;
            if ((button13.Text != "X") && (button13.Text != "O")) return false;
            if ((button21.Text != "X") && (button21.Text != "O")) return false;
            if ((button22.Text != "X") && (button22.Text != "O")) return false;
            if ((button23.Text != "X") && (button23.Text != "O")) return false;
            if ((button31.Text != "X") && (button31.Text != "O")) return false;
            if ((button32.Text != "X") && (button32.Text != "O")) return false;
            if ((button33.Text != "X") && (button33.Text != "O")) return false;
            return true;
        }
        private bool winnerChecker(string c)
        {
            if ((button11.Text == c) && (button12.Text == c) && (button13.Text == c))
                return true;
            if ((button21.Text == c) && (button22.Text == c) && (button23.Text == c))
                return true;
            if ((button31.Text == c) && (button32.Text == c) && (button33.Text == c))
                return true;


            if ((button11.Text == c) && (button22.Text == c) && (button33.Text == c))
                return true;
            if ((button13.Text == c) && (button22.Text == c) && (button31.Text == c))
                return true;


            if ((button11.Text == c) && (button21.Text == c) && (button31.Text == c))
                return true;
            if ((button12.Text == c) && (button22.Text == c) && (button32.Text == c))
                return true;
            if ((button13.Text == c) && (button23.Text == c) && (button33.Text == c))
                return true;

            else return false;
        }


        private static int player1counter = 0;
        private static int player2counter = 0;
        private static int roundsNum = 1;
        private void setText(object sender, EventArgs e)
        {
            Button buttonVar;
            bool win = false;
            bool full = false;
            buttonVar = (Button)sender;
            if ((buttonVar.Text == "X") || (buttonVar.Text == "O")) return;
            if (playerTurn == 1)
            {
                buttonVar.BackColor = Color.Cyan;
                buttonVar.Text = "X";
                win = winnerChecker("X");
                if (win == true)
                {
                    player1counter++;
                    player1Rounds.Text = player1counter.ToString();
                    nextRoundButton.Visible = true;
                    finalWinner();     
                    buttonsLocker(false);

                    return;
                }
                full = fullBoardChecker();
                if (full == true)
                {
                    buttonsLocker(false);
                    nextRoundButton.Visible = true;
                    finalWinner();
                    return;
                }
                playerTurn = 2;
            }
            else
            {
                buttonVar.BackColor = Color.Red;
                buttonVar.Text = "O";
                win = winnerChecker("O");
                if (win == true)
                {
                    player2counter++;
                    player2Rounds.Text = player2counter.ToString();
                    nextRoundButton.Visible = true;
                    finalWinner();
                    buttonsLocker(false);
       
                    return;
                }
                full = fullBoardChecker();
                if (full == true)
                {
                    buttonsLocker(false);
                    nextRoundButton.Visible = true;
                    finalWinner();
                    return;
                }
                playerTurn = 1;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void button33_Click_1(object sender, EventArgs e)
        {
            setText(sender, e);
        }

        private void player1Rounds_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void player2Rounds_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void nextRoundButton_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                {
                    ((Button)control).Text = "";
                    ((Button)control).BackColor = Color.White;
                }

            }
      
            buttonsLocker(true);
            playerTurn = 1;
            nextRoundButton.Text = "Next Round";
            nextRoundButton.Visible = false;
            roundsNum++;
            roundsCounter.Text = roundsNum.ToString();
        }

        private void finalWinner()
        {
            if (playerOneName == playerTwoName)
            {
                playerOneName += "1";
                playerTwoName += "2";
            }
            if (roundsNum == rounds)
            {
                string tmp;
                Color winnerColor;
                if (player1counter > player2counter)
                {
                    tmp = playerOneName + " wins!";
                    winnerColor = Color.Cyan;
                }
                else if (player1counter < player2counter)
                {
                    tmp = playerTwoName + " wins!";
                    winnerColor = Color.Red;
                }
                else
                {
                    tmp = "It's a tie!";
                    winnerColor = Color.Black;
                }
                
                Form3 form3 = new Form3(tmp, winnerColor);
                form3.Show();
                this.Hide();
            }
        }
    }
}
