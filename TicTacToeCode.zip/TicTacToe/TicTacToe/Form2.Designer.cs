﻿namespace TicTacToe
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.player1Name = new System.Windows.Forms.Label();
            this.player2Name = new System.Windows.Forms.Label();
            this.player1Rounds = new System.Windows.Forms.TextBox();
            this.player2Rounds = new System.Windows.Forms.TextBox();
            this.roundsCounter = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nextRoundButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button11.Location = new System.Drawing.Point(241, 51);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(125, 125);
            this.button11.TabIndex = 0;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button12.Location = new System.Drawing.Point(372, 51);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(125, 125);
            this.button12.TabIndex = 1;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button13.Location = new System.Drawing.Point(503, 51);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(125, 125);
            this.button13.TabIndex = 2;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button23.Location = new System.Drawing.Point(503, 182);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(125, 125);
            this.button23.TabIndex = 5;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button22.Location = new System.Drawing.Point(372, 182);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(125, 125);
            this.button22.TabIndex = 4;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button21.Location = new System.Drawing.Point(241, 182);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(125, 125);
            this.button21.TabIndex = 3;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button33.Location = new System.Drawing.Point(503, 313);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(125, 125);
            this.button33.TabIndex = 8;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click_1);
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button32.Location = new System.Drawing.Point(372, 313);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(125, 125);
            this.button32.TabIndex = 7;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button31.Location = new System.Drawing.Point(241, 313);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(125, 125);
            this.button31.TabIndex = 6;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // player1Name
            // 
            this.player1Name.AutoSize = true;
            this.player1Name.BackColor = System.Drawing.Color.Transparent;
            this.player1Name.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.player1Name.ForeColor = System.Drawing.Color.Cyan;
            this.player1Name.Location = new System.Drawing.Point(12, 51);
            this.player1Name.Name = "player1Name";
            this.player1Name.Size = new System.Drawing.Size(0, 46);
            this.player1Name.TabIndex = 9;
            this.player1Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player2Name
            // 
            this.player2Name.AutoSize = true;
            this.player2Name.BackColor = System.Drawing.Color.Transparent;
            this.player2Name.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.player2Name.ForeColor = System.Drawing.Color.Red;
            this.player2Name.Location = new System.Drawing.Point(12, 182);
            this.player2Name.Name = "player2Name";
            this.player2Name.Size = new System.Drawing.Size(0, 46);
            this.player2Name.TabIndex = 10;
            this.player2Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player1Rounds
            // 
            this.player1Rounds.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player1Rounds.Location = new System.Drawing.Point(12, 103);
            this.player1Rounds.Name = "player1Rounds";
            this.player1Rounds.Size = new System.Drawing.Size(125, 41);
            this.player1Rounds.TabIndex = 11;
            this.player1Rounds.TextChanged += new System.EventHandler(this.player1Rounds_TextChanged);
            // 
            // player2Rounds
            // 
            this.player2Rounds.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player2Rounds.Location = new System.Drawing.Point(12, 234);
            this.player2Rounds.Name = "player2Rounds";
            this.player2Rounds.Size = new System.Drawing.Size(125, 41);
            this.player2Rounds.TabIndex = 12;
            this.player2Rounds.TextChanged += new System.EventHandler(this.player2Rounds_TextChanged);
            // 
            // roundsCounter
            // 
            this.roundsCounter.AutoSize = true;
            this.roundsCounter.BackColor = System.Drawing.Color.Transparent;
            this.roundsCounter.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.roundsCounter.Location = new System.Drawing.Point(787, 52);
            this.roundsCounter.Name = "roundsCounter";
            this.roundsCounter.Size = new System.Drawing.Size(40, 46);
            this.roundsCounter.TabIndex = 13;
            this.roundsCounter.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(647, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 46);
            this.label1.TabIndex = 14;
            this.label1.Text = "Round:";
            // 
            // nextRoundButton
            // 
            this.nextRoundButton.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nextRoundButton.Location = new System.Drawing.Point(647, 209);
            this.nextRoundButton.Name = "nextRoundButton";
            this.nextRoundButton.Size = new System.Drawing.Size(180, 66);
            this.nextRoundButton.TabIndex = 15;
            this.nextRoundButton.Text = "Next Round";
            this.nextRoundButton.UseVisualStyleBackColor = true;
            this.nextRoundButton.Click += new System.EventHandler(this.nextRoundButton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(869, 489);
            this.Controls.Add(this.nextRoundButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.roundsCounter);
            this.Controls.Add(this.player2Rounds);
            this.Controls.Add(this.player1Rounds);
            this.Controls.Add(this.player2Name);
            this.Controls.Add(this.player1Name);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TicTacToe";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button11;
        private Button button12;
        private Button button13;
        private Button button23;
        private Button button22;
        private Button button21;
        private Button button33;
        private Button button32;
        private Button button31;
        private Label player1Name;
        private Label player2Name;
        private TextBox player1Rounds;
        private TextBox player2Rounds;
        private Label roundsCounter;
        private Label label1;
        private Button nextRoundButton;
    }
}