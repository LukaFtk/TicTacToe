﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.playButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.confirmButton = new System.Windows.Forms.Button();
            this.roundsLabel = new System.Windows.Forms.Label();
            this.roundsNumber = new System.Windows.Forms.TextBox();
            this.playertwoName = new System.Windows.Forms.TextBox();
            this.playeroneName = new System.Windows.Forms.TextBox();
            this.playertwoLabel = new System.Windows.Forms.Label();
            this.playeroneLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // playButton
            // 
            this.playButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.playButton.BackColor = System.Drawing.Color.LightBlue;
            this.playButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.playButton.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.playButton.Location = new System.Drawing.Point(271, 330);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(327, 147);
            this.playButton.TabIndex = 0;
            this.playButton.Text = "Play";
            this.playButton.UseVisualStyleBackColor = false;
            this.playButton.Click += new System.EventHandler(this.playButton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(221, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(426, 52);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome to TicTacToe";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // confirmButton
            // 
            this.confirmButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.confirmButton.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.confirmButton.Location = new System.Drawing.Point(494, 266);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(233, 87);
            this.confirmButton.TabIndex = 13;
            this.confirmButton.Text = "Confirm";
            this.confirmButton.UseVisualStyleBackColor = true;
            this.confirmButton.Click += new System.EventHandler(this.confirmButton_Click);
            // 
            // roundsLabel
            // 
            this.roundsLabel.AutoSize = true;
            this.roundsLabel.BackColor = System.Drawing.Color.Transparent;
            this.roundsLabel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.roundsLabel.Location = new System.Drawing.Point(141, 266);
            this.roundsLabel.Name = "roundsLabel";
            this.roundsLabel.Size = new System.Drawing.Size(165, 35);
            this.roundsLabel.TabIndex = 12;
            this.roundsLabel.Text = "Enter rounds";
            // 
            // roundsNumber
            // 
            this.roundsNumber.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.roundsNumber.Location = new System.Drawing.Point(141, 314);
            this.roundsNumber.Name = "roundsNumber";
            this.roundsNumber.Size = new System.Drawing.Size(157, 39);
            this.roundsNumber.TabIndex = 11;
            // 
            // playertwoName
            // 
            this.playertwoName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.playertwoName.Location = new System.Drawing.Point(494, 201);
            this.playertwoName.Name = "playertwoName";
            this.playertwoName.Size = new System.Drawing.Size(233, 39);
            this.playertwoName.TabIndex = 10;
            // 
            // playeroneName
            // 
            this.playeroneName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.playeroneName.Location = new System.Drawing.Point(141, 201);
            this.playeroneName.Name = "playeroneName";
            this.playeroneName.Size = new System.Drawing.Size(233, 39);
            this.playeroneName.TabIndex = 9;
            // 
            // playertwoLabel
            // 
            this.playertwoLabel.AutoSize = true;
            this.playertwoLabel.BackColor = System.Drawing.Color.Transparent;
            this.playertwoLabel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.playertwoLabel.Location = new System.Drawing.Point(494, 147);
            this.playertwoLabel.Name = "playertwoLabel";
            this.playertwoLabel.Size = new System.Drawing.Size(247, 35);
            this.playertwoLabel.TabIndex = 8;
            this.playertwoLabel.Text = "Enter Player2 Name";
            // 
            // playeroneLabel
            // 
            this.playeroneLabel.AutoSize = true;
            this.playeroneLabel.BackColor = System.Drawing.Color.Transparent;
            this.playeroneLabel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.playeroneLabel.Location = new System.Drawing.Point(141, 147);
            this.playeroneLabel.Name = "playeroneLabel";
            this.playeroneLabel.Size = new System.Drawing.Size(247, 35);
            this.playeroneLabel.TabIndex = 7;
            this.playeroneLabel.Text = "Enter Player1 Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(869, 489);
            this.Controls.Add(this.confirmButton);
            this.Controls.Add(this.roundsLabel);
            this.Controls.Add(this.roundsNumber);
            this.Controls.Add(this.playertwoName);
            this.Controls.Add(this.playeroneName);
            this.Controls.Add(this.playertwoLabel);
            this.Controls.Add(this.playeroneLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.playButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MdiChildrenMinimizedAnchorBottom = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "";
            this.Text = "TicTacToe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button playButton;
        private Label label1;
        private Button confirmButton;
        private Label roundsLabel;
        private TextBox roundsNumber;
        private TextBox playertwoName;
        private TextBox playeroneName;
        private Label playertwoLabel;
        private Label playeroneLabel;
    }
}