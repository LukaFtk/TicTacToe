﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form3 : Form
    {
        private string winner;
        private Color winnerColor;
        private SoundPlayer soundPlayer;
        public Form3(string winner, Color winnerColor)
        {
            InitializeComponent();
            this.winner = winner;

            soundPlayer = new SoundPlayer("winnerSound.wav");
            this.winnerColor = winnerColor;
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void winnerLabel_Click(object sender, EventArgs e)
        {
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
 
            soundPlayer.Play();
            winnerLabel.Text = winner;
            winnerLabel.ForeColor = winnerColor;
        }
    }
}
